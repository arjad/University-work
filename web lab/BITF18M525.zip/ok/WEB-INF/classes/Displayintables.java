import java.sql.Driver;
import javax.servlet.*;
import java.io.*;
import java.net.*;
import java.util.*;
import java.sql.*;
import javax.servlet.http.*;
import javax.servlet.*;
import java.net.*;

public class Displayintables extends HttpServlet 
{
	String url;
	Statement s;
	Connection con;

	public void doPost(HttpServletRequest request, HttpServletResponse response)
throws ServletException, IOException 
	{
       	PrintWriter out = response.getWriter();
        try
	{       

System.out.println("try block");
		//// connecting DB s
	        Class.forName("com.mysql.jdbc.Driver");
         	url= "jdbc:mysql://localhost/store";
		con=DriverManager.getConnection(url,"root","root");
		 s=con.createStatement();
         	
		String q="select * from items ";
       	 	ResultSet rs = s.executeQuery(q);  
	     	System.out.println(rs);
		
		////html code
      	            out.write("<html><body<table> <tr><th> Item Name</th>");
			        out.println("<th> Description</th>");
			        out.println("<th>Price</th>");
			        out.println("</tr>"); 
		
String desc;	
String i;
int p;

			while(rs.next())
			{ 
		        	i = rs.getString("itemname");
		       		desc = rs.getString("Description");
		        	p=rs.getInt("price");
	            
		    System.out.println(rs);
                    out.println("<tr><td>" + i + "</td>");
					
		    out.println("<td> "+ desc + "</td>");
					
		    out.println("<td>"+p+"</td></tr>");
			}
                    out.println("</table><br>end</body></html>");
	  
        }		
       catch(Exception e)
 	{
		out.println( "STOP -  ERROR !!!  " +e );	
        }
	}
}
         