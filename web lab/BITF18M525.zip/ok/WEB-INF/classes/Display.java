import java.io.*;
import javax.servlet.http.*;
import javax.servlet.*;
import java.net.*;
import java.util.*;
import java.sql.*;

public class Display extends HttpServlet 
{
	String url;
	Statement s;
	Connection con;

	public void doPost(HttpServletRequest request, HttpServletResponse response)
throws ServletException, IOException 
	{
       	PrintWriter out = response.getWriter();
        try
	{
System.out.println("try block");
        String i_name = request.getParameter("name");       
        Class.forName("com.mysql.jdbc.Driver");
       	
	url= "jdbc:mysql://localhost/store";
	con=DriverManager.getConnection(url,"root","root");
		
        s=con.createStatement();
	HttpSession session = request.getSession();
			String q ="select * from items where itemname='"+i_name+"' ";
       	   		ResultSet rs = s.executeQuery(q); 	//executing sql statement
			if(rs.next())
			{
				session.setAttribute("name" , i_name);
				RequestDispatcher rd = request.getRequestDispatcher("/main");
				request.setAttribute("name",i_name);
				rd.forward(request,response);	
	              	}
			else if(!rs.next())
		        { 
				//// to error page
	            		RequestDispatcher rd2 = request.getRequestDispatcher("/error");  
                 		rd2.forward(request,response);					 
                	}
        }
        catch(Exception e)
 	{
		out.println( "STOP -  ERROR !!!  " +e );	
        }
	}
}