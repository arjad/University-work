import java.io.*;
import javax.servlet.http.*;
import javax.servlet.*;
import java.sql.*; 
import java.util.*;

public class Greeting2 extends HttpServlet {

	String url,query;
	Statement s;
	Connection con;
	ResultSet rs;
	int rs_i;

	public void database()
	{
		try
		{
		Class.forName("com.mysql.jdbc.Driver");
		url= "jdbc:mysql://localhost/db";
		con=DriverManager.getConnection(url,"root","root");
		s=con.createStatement();
		}
		catch(Exception ex)
		{
			System.out.println(ex);
		}
	}
	
//////////////////////////////////////////////////
	public void signin(String e,String p)
	{
		try
		{
			query=" select * from tb where email = '"+e+"' and password= '" + p + "' " ;
			rs = s.executeQuery(query);
		
			if (rs.next())
			{
				System.out.print("====  Login Successful  ==== \n\n");		
				System.out.print("Login INFO\n");
	
					String fname = rs. getString(1);
					String lname = rs. getString(2);
					String emails = rs . getString(3);
					String passwords = rs .getString(4);

				System.out.println(" First Name= "+fname +"\n Last Name =  "+ lname + "\n Email = "+ emails +"\n Password=   " +passwords);
			}
		}
		catch(Exception ex)
		{
			System.out.println("ERROR !!! \t" +ex);
		}
		
	}


//////////////////////////////////////////////////////////////////////////////////////	
	public void createaccount(String fname,String lname, String email,String password)
	{ 	
		System.out.print("====  Create Account  ==== \n\n");	
		try
		{
			query="insert tb(fname, lname,email, password) values ('"+ fname +"', '" + lname+"', '"+ email+"', '"+ password+"')";
			rs_i = s.executeUpdate(query);

					System.out.print("\nafter creting account");
				System.out.println(" First Name= "+fname +"\n Last Name =  "+ lname + "\n Email = "+ email +"\n Password=   " +password);
			
		}
		
		catch(Exception ex)
		{
			System.out.print("\n Error - Exception");
		}
		if(rs_i > 0)
		{
			System.out.print("\n Account Created in DATABASE\n");
		}
     		else
		{	
			System.out.print("Account Exists Already\n");
        	}
	}

//////////////////////////////////////////////////////////////////////////////////////	
	public void updateprofile(String e_mail,String value,int c)
	{
		System.out.print("====  Update Profile  ==== \n\n");	
		if (c == 1)
		{
			query = "update tb set fname='"+ value +"' where email= '"+ e_mail +"' ";
		}
		else if (c == 2)
		{
			query = "update tb set lname='"+ value +"' where email= '"+ e_mail +"' ";
		}	
		else if (c == 3)
		{
			query = "update tb set email='"+ value +"' where email= '"+ e_mail +"' ";
		
		}
		else if (c == 4)
		{
			query = "update tb set password='"+ value +"' where email= '"+ e_mail +"' ";	
		}
		try
		{
			rs_i = s.executeUpdate(query);
		}
		catch(Exception ex)
		{
			System.out.println(" ERROR !!! " + ex);
			return;
		}
		
		if(rs_i > 0)
		{
			System.out.print("\n  Account Updated\n");
		}
     		else
		{
			System.out.println("\n Cannot Update \n");
			System.out.println(rs_i);

       		}
		
	}
	
//////////////////////////////////////////////////////////////////////////////////////	

public static void main(String []args)
	{
		Greeting2 w = new Greeting2();
        	w.database();
		
		int choice;
		System.out.print("Press      1 for sign up or create account \n\t2 for login \n\t3 for updating");
		Scanner i= new Scanner(System.in);
		choice = i.nextInt();
		
		if(choice == 1)
		{
		w.createaccount("arjad3","gohar3","arjad@gmail.com3","1233");
		}
		else if(choice ==2)
		{
		w.signin("arjad@gmail.com2","1232");
		}     	
		else if(choice ==3)
		{
		w.updateprofile("arjad@pucit","ahmed",1);
		}
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException 
	{        
    //response.setContentType("text/html");
    PrintWriter out = response.getWriter();

    String f = request.getParameter("fname");
    String l = request.getParameter("lname");
    String e = request.getParameter("email");
    String p1 = request.getParameter("pass1");
    String p2 = request.getParameter("pass2");

    out.println("<html>");
    out.println("<head>");
    out.println("<title>Sign up </title>");
    out.println("</head>");
    out.println("<body>");

    out.println("<p>fname=  " + f + "\nLname= " + l + "\nemail =" + e + "\npasswor1  =" + p1 + "\npassword2 = " + p2 + " </p>");
    out.println("</body>");
    out.println("</html>");
    out.close(); 

	
	}


}