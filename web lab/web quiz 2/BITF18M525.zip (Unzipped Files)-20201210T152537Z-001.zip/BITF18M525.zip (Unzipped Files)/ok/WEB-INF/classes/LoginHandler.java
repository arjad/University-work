import java.io.*;
import javax.servlet.http.*;
import javax.servlet.*;

public class LoginHandler extends HttpServlet {

public void doPost(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException 
	{        
		
     //response.setContentType("text/html");
    PrintWriter out = response.getWriter();

    String email = request.getParameter("email");
    String pass = request.getParameter("pass");

String[][] login = {
{"marcin", "testpaswrd"},
{"Robert", "Delgro1234"},
{"James", "Gosling"},
};

    out.println("<html>");
    out.println("<head>");
    out.println("<title>Servlet GreetingServlet</title>");
    out.println("</head>");
    out.println("<body>");
    out.println("<p>Your Given EMAIL =  " + email + "Your Given PASSWORD =  " + pass + " . </p>");
    out.println("</body>");
    out.println("<script>if(email==login[0][0] || email==login[1][0] || email==login[2][0]){alert("email matches"} else{alert("email not matches")} 	</script>");
    out.println("<script>if(email==login[0][1] || email==login[1][1] || email==login[2][1]){alert("pass matches"} else{alert("pass not matches")} 	</script>");

    out.println("</html>");
    out.close(); 

	
	}


}